#incluir <port.h>
principal(){
   inteiro a;
   ler("%d", &a);
   se(a >= 0){
   escrever("numero positivo ou nulo\n");     
        }   
   senao { 
   escrever("numero negativo");      
            }
   sistema("pause");
            }