#incluir <port.h>
principal(){
   inteiro a;
   escrever("digite quantas vezes voc� quer que o programa te d� bom dia\n");
   ler("%d", a);
   enquanto(a > 0) {
   escrever("!bom dia\n");
   a--;           
              }
            }
