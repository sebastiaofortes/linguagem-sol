#incluir <port.h>
principal() {
      escrever("ola mundo\n");
      sistema("PAUSE");      
       
       }